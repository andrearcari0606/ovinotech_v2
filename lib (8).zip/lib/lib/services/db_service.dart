import 'package:hive_flutter/hive_flutter.dart';
import '../../models/animal.dart';

class DBService {
  static const String _boxName = 'animals';

  static Future<void> init() async {
    if (!Hive.isAdapterRegistered(0)) {
      Hive.registerAdapter(AnimalAdapter());
    }

    if (!Hive.isBoxOpen(_boxName)) {
      await Hive.openBox<Animal>(_boxName);
    }
  }

  static Box<Animal> get box => Hive.box<Animal>(_boxName);

  static List<Animal> getAnimals() {
    return box.values.toList();
  }

  static Future<void> addAnimal(Animal animal) async {
    if (animal.id == null || animal.id!.isEmpty) {
      animal.id = DateTime.now().millisecondsSinceEpoch.toString();
    }

    await box.put(animal.id, animal);
  }

  static Animal? getById(String id) {
    return box.get(id);
  }

  static Future<void> delete(String id) async {
    await box.delete(id);
  }
}