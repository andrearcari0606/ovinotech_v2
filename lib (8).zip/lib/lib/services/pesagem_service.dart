import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:hive/hive.dart';
import '../models/pesagem.dart';

class PesagemService {
  final _firestore = FirebaseFirestore.instance;
  final _auth = FirebaseAuth.instance;

  /// 🔥 CORREÇÃO (NÃO INICIALIZA DIRETO)
  Box<Pesagem> get box => Hive.box<Pesagem>('pesagens');

  String get userId => _auth.currentUser!.uid;

  Future<void> salvarPesagem(Pesagem pesagem) async {
    try {
      /// 🔥 SALVA LOCAL
      await box.put(pesagem.id, pesagem);

      /// 🔥 SALVA NO FIREBASE
      await _firestore
          .collection('usuarios')
          .doc(userId)
          .collection('pesagens')
          .doc(pesagem.id)
          .set(pesagem.toMap());

    } catch (e) {
      print("ERRO AO SALVAR PESAGEM: $e");
      rethrow;
    }
  }

  List<Pesagem> listarPorAnimal(String animalId) {
    return box.values
        .where((p) => p.animalId == animalId)
        .toList()
      ..sort((a, b) => b.data.compareTo(a.data));
  }
}