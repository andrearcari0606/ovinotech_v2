import 'package:hive_flutter/hive_flutter.dart';
import '../models/famacha.dart';

class FamachaService {

  Future<Box<Famacha>> _getBox() async {

    /// 🔴 GARANTE ADAPTER
    if (!Hive.isAdapterRegistered(2)) {
      Hive.registerAdapter(FamachaAdapter());
    }

    /// 🔴 GARANTE BOX TIPADO
    if (!Hive.isBoxOpen('famacha')) {
      return await Hive.openBox<Famacha>('famacha');
    }

    return Hive.box<Famacha>('famacha');
  }

  Future<void> salvar(Famacha f) async {
    final box = await _getBox();
    await box.put(f.id, f);
  }

  Future<List<Famacha>> listarPorAnimal(String animalId) async {
    final box = await _getBox();

    return box.values
        .where((f) => f.animalId == animalId)
        .toList()
      ..sort((a, b) => b.data.compareTo(a.data));
  }
}