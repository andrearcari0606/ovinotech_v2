import 'package:hive_flutter/hive_flutter.dart';
import '../models/ecc.dart';

class ECCService {

  Future<Box<ECC>> _getBox() async {

    if (!Hive.isAdapterRegistered(4)) {
      Hive.registerAdapter(ECCAdapter());
    }

    if (!Hive.isBoxOpen('ecc')) {
      return await Hive.openBox<ECC>('ecc');
    }

    return Hive.box<ECC>('ecc');
  }

  Future<void> salvar(ECC ecc) async {
    final box = await _getBox();
    await box.put(ecc.id, ecc);
  }

  Future<List<ECC>> listarPorAnimal(String animalId) async {
    final box = await _getBox();

    return box.values
        .where((e) => e.animalId == animalId)
        .toList()
      ..sort((a, b) => b.data.compareTo(a.data));
  }
}