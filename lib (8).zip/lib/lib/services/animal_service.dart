import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../core/services/db_service.dart';
import '../../models/animal.dart';

class AnimalService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  /// 🔒 USUÁRIO
  Future<String> _getUserId() async {
    User? user = _auth.currentUser;

    if (user == null) {
      final cred = await _auth.signInAnonymously();
      user = cred.user;
    }

    if (user == null) {
      throw Exception('Falha ao autenticar usuário');
    }

    return user.uid;
  }

  /// 🔥 SALVAR ANIMAL (OFFLINE FIRST)
  Future<void> salvarAnimal(Animal animal) async {
    try {
      final id = DateTime.now().millisecondsSinceEpoch.toString();
      animal.id = id;

      /// ✅ SALVA LOCAL
      await DBService.addAnimal(animal);

      /// 🔥 FIREBASE (SEM TRAVAR)
      try {
        final userId = await _getUserId();

        await _firestore
            .collection('usuarios')
            .doc(userId)
            .collection('rebanho')
            .doc(id)
            .set(animal.toMap());

        print("🔥 Animal salvo no Firebase");
      } catch (e) {
        print("⚠️ Firebase falhou: $e");
      }
    } catch (e) {
      print("❌ Erro ao salvar animal: $e");
      rethrow;
    }
  }

  /// 📥 LISTAR (AGORA PADRONIZADO)
  List<Animal> listar() {
    return DBService.getAnimals();
  }

  /// 🔍 BUSCAR
  Animal? buscarPorId(String id) {
    return DBService.getById(id);
  }

  /// 🗑️ REMOVER
  Future<void> remover(String id) async {
    try {
      await DBService.delete(id);

      try {
        final userId = await _getUserId();

        await _firestore
            .collection('usuarios')
            .doc(userId)
            .collection('rebanho')
            .doc(id)
            .delete();
      } catch (e) {
        print("⚠️ Falha ao remover Firebase: $e");
      }
    } catch (e) {
      print("Erro ao remover animal: $e");
      rethrow;
    }
  }

  /// 🔄 SINCRONIZAR
  Future<void> sincronizar() async {
    try {
      final userId = await _getUserId();

      final snapshot = await _firestore
          .collection('usuarios')
          .doc(userId)
          .collection('rebanho')
          .get();

      for (var doc in snapshot.docs) {
        final animal = Animal.fromMap(doc.data(), doc.id);
        await DBService.addAnimal(animal);
      }

      print("🔄 Sincronização concluída");
    } catch (e) {
      print("Erro ao sincronizar: $e");
    }
  }

  /// 🧠 CATEGORIA AUTOMÁTICA
  static String calcularCategoria(DateTime dataNascimento, String sexo) {
    final idadeDias = DateTime.now().difference(dataNascimento).inDays;

    if (idadeDias < 120) {
      return sexo == "Macho" ? "Cordeiro" : "Cordeira";
    }

    if (idadeDias < 365) {
      return sexo == "Macho" ? "Borrego" : "Borrega";
    }

    return sexo == "Macho" ? "Carneiro" : "Ovelha";
  }
}