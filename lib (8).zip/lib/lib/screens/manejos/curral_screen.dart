import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../../models/animal.dart';
import '../../models/pesagem.dart';
import '../../models/famacha.dart';
import '../../models/ecc.dart';

import '../../services/pesagem_service.dart';
import '../../services/famacha_service.dart';
import '../../services/ecc_service.dart';
import '../../services/animal_service.dart';

import '../../core/services/db_service.dart';

class CurralScreen extends StatefulWidget {
  final List<Animal>? animaisFiltrados;

  const CurralScreen({super.key, this.animaisFiltrados});

  @override
  State<CurralScreen> createState() => _CurralScreenState();
}

class ManejoTemp {
  double? peso;
  int? famacha;
  int? ecc;
}

class _CurralScreenState extends State<CurralScreen> {
  final TextEditingController pesoController = TextEditingController();
  final TextEditingController buscaController = TextEditingController();

  final Map<String, ManejoTemp> dados = {};
  final animalService = AnimalService();

  Animal? animalSelecionado;
  int indexAtual = 0;

  List<Animal> get lista =>
      widget.animaisFiltrados ?? animalService.listar();

  String getId(Animal a) => a.id ?? a.brinco ?? a.hashCode.toString();

  ManejoTemp getAtual(Animal a) {
    final id = getId(a);
    dados.putIfAbsent(id, () => ManejoTemp());
    return dados[id]!;
  }

  @override
  void initState() {
    super.initState();
    if (lista.isNotEmpty) {
      animalSelecionado = lista.first;
    }
  }

  void mostrarInfo(String texto) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Text(texto, textAlign: TextAlign.center),
        ),
      ),
    );
  }

  Color corStatus(ManejoTemp m) {
    if (m.famacha == null && m.ecc == null) return Colors.grey;

    if ((m.famacha ?? 0) >= 4 || (m.ecc ?? 5) <= 2) {
      return Colors.red;
    }

    if ((m.famacha ?? 0) == 3) {
      return Colors.orange;
    }

    return Colors.green;
  }

  /// 🔥 CORREÇÃO AQUI (100% segura)
  Future<void> salvarParcial(Animal a, ManejoTemp m) async {
    final id = getId(a);
    final now = DateTime.now();

    /// GARANTE BOXES ABERTOS
    final famachaBox = Hive.isBoxOpen('famacha')
        ? Hive.box<Famacha>('famacha')
        : await Hive.openBox<Famacha>('famacha');

    final eccBox = Hive.isBoxOpen('ecc')
        ? Hive.box<ECC>('ecc')
        : await Hive.openBox<ECC>('ecc');

    if (m.famacha != null) {
      await famachaBox.add(Famacha(
        id: now.millisecondsSinceEpoch.toString(),
        animalId: id,
        nota: m.famacha!,
        data: now,
      ));
    }

    if (m.ecc != null) {
      await eccBox.add(ECC(
        id: now.millisecondsSinceEpoch.toString(),
        animalId: id,
        nota: m.ecc!,
        data: now,
      ));
    }

    if (m.peso != null) {
      final p = Pesagem(
        id: now.millisecondsSinceEpoch.toString(),
        animalId: id,
        peso: m.peso!,
        data: now,
        observacao: "Curral",
      );

      await PesagemService().salvarPesagem(p);
      a.peso = m.peso!;
      await DBService.addAnimal(a);
    }
  }

  void proximoAnimal() async {
    final a = animalSelecionado!;
    final m = getAtual(a);

    await salvarParcial(a, m);

    if (indexAtual < lista.length - 1) {
      setState(() {
        indexAtual++;
        animalSelecionado = lista[indexAtual];

        final novoM = getAtual(animalSelecionado!);
        pesoController.text =
            novoM.peso != null ? novoM.peso.toString() : "";
      });
    } else {
      mostrarResumo();
    }
  }

  void voltarAnimal() {
    if (indexAtual > 0) {
      setState(() {
        indexAtual--;
        animalSelecionado = lista[indexAtual];

        final m = getAtual(animalSelecionado!);
        pesoController.text =
            m.peso != null ? m.peso.toString() : "";
      });
    }
  }

  void pularAnimal() {
    if (indexAtual < lista.length - 1) {
      setState(() {
        indexAtual++;
        animalSelecionado = lista[indexAtual];
        pesoController.clear();
      });
    } else {
      mostrarResumo();
    }
  }

  void mostrarResumo() {
    int saudavel = 0;
    int atencao = 0;
    int critico = 0;

    for (var m in dados.values) {
      if ((m.famacha ?? 0) >= 4 || (m.ecc ?? 5) <= 2) {
        critico++;
      } else if ((m.famacha ?? 0) == 3) {
        atencao++;
      } else {
        saudavel++;
      }
    }

    mostrarInfo(
        "Resumo do lote\n\n🟢 Saudáveis: $saudavel\n🟠 Atenção: $atencao\n🔴 Críticos: $critico");
  }

  @override
  Widget build(BuildContext context) {
    final animal = animalSelecionado;

    if (animal == null) {
      return Scaffold(
        appBar: AppBar(title: const Text("Modo Curral")),
        body: const Center(child: Text("Nenhum animal disponível")),
      );
    }

    final m = getAtual(animal);
    final statusCor = corStatus(m);

    return Scaffold(
      appBar: AppBar(title: const Text("Modo Curral")),

      body: GestureDetector(
        onHorizontalDragEnd: (details) {
          if (details.primaryVelocity! < 0) {
            proximoAnimal();
          } else if (details.primaryVelocity! > 0) {
            voltarAnimal();
          }
        },
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [

              TextField(
                controller: buscaController,
                decoration: InputDecoration(
                  labelText: "Buscar brinco",
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),

              const SizedBox(height: 16),

              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Animal ${indexAtual + 1} de ${lista.length}"),
                  const SizedBox(height: 6),
                  LinearProgressIndicator(
                    value: (indexAtual + 1) / lista.length,
                    minHeight: 10,
                  ),
                ],
              ),

              const SizedBox(height: 16),

              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: statusCor.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: statusCor, width: 2),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Brinco ${animal.brinco}",
                        style: const TextStyle(
                            fontSize: 22, fontWeight: FontWeight.bold)),
                    Text("🐑 ${animal.categoria}"),
                    Text("⚖️ ${animal.peso.toStringAsFixed(1)} kg"),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              /// FAMACHA
              Row(
                children: List.generate(5, (i) {
                  final v = i + 1;

                  Color cor = [
                    Colors.red.shade900,
                    Colors.red,
                    Colors.pink,
                    Colors.pink.shade100,
                    Colors.grey.shade200
                  ][i];

                  final selecionado = m.famacha == v;

                  return Expanded(
                    child: GestureDetector(
                      onTap: () async {
                        setState(() => m.famacha = v);
                        await salvarParcial(animal, m);
                      },
                      onLongPress: () => mostrarInfo("Famacha $v"),
                      child: Container(
                        height: 55,
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        decoration: BoxDecoration(
                          color: cor,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        alignment: Alignment.center,
                        child: Text("$v"),
                      ),
                    ),
                  );
                }),
              ),

              const SizedBox(height: 16),

              /// ECC
              Column(
                children: List.generate(5, (i) {
                  final textos = [
                    "Muito magro",
                    "Magro",
                    "Ideal",
                    "Gordo",
                    "Muito gordo"
                  ];

                  final selecionado = m.ecc == i + 1;

                  return GestureDetector(
                    onTap: () async {
                      setState(() => m.ecc = i + 1);
                      await salvarParcial(animal, m);
                    },
                    child: Container(
                      width: double.infinity,
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: selecionado
                            ? Colors.green.withOpacity(0.2)
                            : Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(textos[i]),
                    ),
                  );
                }),
              ),

              const SizedBox(height: 16),

              TextField(
                controller: pesoController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: "Peso"),
                onChanged: (v) async {
                  m.peso = double.tryParse(v);
                  await salvarParcial(animal, m);
                },
              ),

              const SizedBox(height: 20),

              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: indexAtual == 0 ? null : voltarAnimal,
                      child: const Text("Voltar"),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: pularAnimal,
                      child: const Text("Pular"),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: proximoAnimal,
                      child: const Text("Próximo"),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}