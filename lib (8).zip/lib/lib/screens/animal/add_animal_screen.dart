
import 'package:flutter/material.dart';
import '../../models/animal.dart';
import '../../services/db_service.dart';

class AddAnimalScreen extends StatefulWidget {
  const AddAnimalScreen({super.key});

  @override
  State<AddAnimalScreen> createState() => _AddAnimalScreenState();
}

class _AddAnimalScreenState extends State<AddAnimalScreen> {

  final brinco = TextEditingController();
  final nome = TextEditingController();
  final raca = TextEditingController();
  final peso = TextEditingController();

  void salvar(){

    final animal = Animal(
      brinco: brinco.text,
      nome: nome.text,
      sexo: "Fêmea",
      categoria: "Ovelha",
      raca: raca.text,
      peso: double.tryParse(peso.text) ?? 0,
    );

    DBService.addAnimal(animal);
    Navigator.pop(context);

  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(title: const Text("Cadastrar Animal")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: brinco, decoration: const InputDecoration(labelText: "Brinco")),
            TextField(controller: nome, decoration: const InputDecoration(labelText: "Nome")),
            TextField(controller: raca, decoration: const InputDecoration(labelText: "Raça")),
            TextField(controller: peso, decoration: const InputDecoration(labelText: "Peso")),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: salvar, child: const Text("Salvar"))
          ],
        ),
      ),
    );

  }

}
