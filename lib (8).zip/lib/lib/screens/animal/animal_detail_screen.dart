import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:fl_chart/fl_chart.dart';

import '../../models/animal.dart';
import '../../models/pesagem.dart';
import '../../models/ecc.dart';
import '../../models/famacha.dart';
import '../../models/manejo.dart'; // 🔥 NOVO

import '../../services/analise_service.dart';
import '../../services/manejo_service.dart'; // 🔥 NOVO

import '../../widgets/analysis_card.dart';

import '../../widgets/manejo/ecc_section.dart';
import '../../widgets/manejo/famacha_section.dart';
import '../../widgets/manejo/pesagem_section.dart';

class AnimalDetailScreen extends StatefulWidget {
  final Animal animal;

  const AnimalDetailScreen({
    super.key,
    required this.animal,
  });

  @override
  State<AnimalDetailScreen> createState() => _AnimalDetailScreenState();
}

class _AnimalDetailScreenState extends State<AnimalDetailScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.animal.identificacao),
      ),
      body: ValueListenableBuilder(
        valueListenable: Hive.box<Pesagem>('pesagens').listenable(),
        builder: (context, Box<Pesagem> box, _) {
          final pesagens = box.values
              .where((p) => p.animalId == widget.animal.id)
              .toList()
            ..sort((a, b) => a.data.compareTo(b.data));

          double gmd = 0;
          double variacao = 0;

          if (pesagens.length >= 2) {
            final primeiro = pesagens.first;
            final ultimo = pesagens.last;

            final dias = ultimo.data.difference(primeiro.data).inDays;

            if (dias > 0) {
              gmd = (ultimo.peso - primeiro.peso) / dias;
            }

            variacao = ultimo.peso - primeiro.peso;
          }

          final resultado = AnaliseService.analisarComDados(
            animal: widget.animal,
            gmd: gmd,
            variacaoPeso: variacao,
          );

          /// 🔥 BUSCAR MANEJOS
          final manejos =
              ManejoService().getPorAnimal(widget.animal.id!);

          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                /// 🔥 HEADER
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  color: Colors.grey.shade100,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (widget.animal.brinco != null &&
                          widget.animal.brinco!.isNotEmpty)
                        Text("Brinco ${widget.animal.brinco}"),

                      Text("${widget.animal.raca} • ${widget.animal.categoria}"),

                      const SizedBox(height: 5),

                      Text(
                        "Peso atual: ${widget.animal.peso.toStringAsFixed(1)} kg",
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),

                      if (variacao != 0)
                        Text(
                          "Variação: ${variacao > 0 ? "+" : ""}${variacao.toStringAsFixed(2)} kg",
                          style: TextStyle(
                            color: variacao > 0 ? Colors.green : Colors.red,
                            fontWeight: FontWeight.bold,
                          ),
                        ),

                      if (gmd != 0)
                        Text(
                          "GMD: ${gmd.toStringAsFixed(3)} kg/dia",
                          style: TextStyle(
                            color: gmd >= 0 ? Colors.green : Colors.red,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                    ],
                  ),
                ),

                /// 🧠 ANÁLISE
                AnalysisCard(resultado: resultado),

                /// 📈 GRÁFICO
                if (pesagens.length >= 2)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: SizedBox(
                      height: 260,
                      child: LineChart(
                        LineChartData(
                          borderData: FlBorderData(show: false),
                          gridData: FlGridData(show: true),
                          titlesData: FlTitlesData(show: false),
                          lineBarsData: [
                            LineChartBarData(
                              isCurved: true,
                              barWidth: 3,
                              color: Colors.green,
                              spots: List.generate(
                                pesagens.length,
                                (i) => FlSpot(i.toDouble(), pesagens[i].peso),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),

                const SizedBox(height: 20),

                /// 🔥 TIMELINE DE MANEJO
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                    "Histórico de Manejo",
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                if (manejos.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(16),
                    child: Text("Nenhum manejo registrado"),
                  ),

                ...manejos.map((m) => _itemTimeline(m)),

                const SizedBox(height: 20),

                /// 🔥 ECC
                ValueListenableBuilder(
                  valueListenable: Hive.box<ECC>('ecc').listenable(),
                  builder: (context, Box<ECC> boxECC, _) {
                    final eccList = boxECC.values
                        .where((e) => e.animalId == widget.animal.id)
                        .toList()
                      ..sort((a, b) => b.data.compareTo(a.data));

                    return ECCSection(eccList: eccList);
                  },
                ),

                const SizedBox(height: 10),

                /// 🔥 FAMACHA
                ValueListenableBuilder(
                  valueListenable: Hive.box<Famacha>('famacha').listenable(),
                  builder: (context, Box<Famacha> boxFamacha, _) {
                    final famachaList = boxFamacha.values
                        .where((f) => f.animalId == widget.animal.id)
                        .toList()
                      ..sort((a, b) => b.data.compareTo(a.data));

                    return FamachaSection(famachaList: famachaList);
                  },
                ),

                const SizedBox(height: 10),

                /// 🔥 PESAGENS
                PesagemSection(pesagens: pesagens),

                const SizedBox(height: 20),
              ],
            ),
          );
        },
      ),
    );
  }

  /// 🔥 ITEM TIMELINE
  Widget _itemTimeline(Manejo m) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.circle, size: 10, color: _corTipo(m.tipo)),
          const SizedBox(width: 10),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(m.descricao,
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 4),
                  Text(
                    "${m.data.day}/${m.data.month} ${m.data.hour}:${m.data.minute.toString().padLeft(2, '0')}",
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _corTipo(String tipo) {
    switch (tipo) {
      case "peso":
        return Colors.blue;
      case "famacha":
        return Colors.red;
      case "ecc":
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }
}