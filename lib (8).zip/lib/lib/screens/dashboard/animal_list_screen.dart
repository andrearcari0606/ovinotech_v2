import 'package:flutter/material.dart';

import '../../models/animal.dart';
import '../../core/services/hive_service.dart';
import '../../core/theme/app_colors.dart';
import '../../services/analise_service.dart';

import '../manejos/curral_screen.dart';

class AnimalListScreen extends StatelessWidget {
  final String tipo;

  const AnimalListScreen({
    super.key,
    required this.tipo,
  });

  @override
  Widget build(BuildContext context) {
    final animais = HiveService.animalBox.values.toList();

    /// 🔥 FILTRO CORRIGIDO (AGORA REAL)
    final filtrados = animais.where((a) {
      final resultado =
          AnaliseService.analisarAnimalCompleto(a);

      final status = resultado.status;

      /// 🔹 DASHBOARD
      if (tipo == "acao") return status == "vermelho";
      if (tipo == "observacao") return status == "amarelo";
      if (tipo == "saudavel") return status == "verde";

      /// 🔥 ALERTAS
      for (var problema in resultado.problemas) {
        if (tipo == "verminose_critica" &&
            problema.mensagem.contains("Forte indicativo")) {
          return true;
        }

        if (tipo == "verminose_atencao" &&
            problema.mensagem.contains("Atenção para verminose")) {
          return true;
        }

        if (tipo == "ecc_baixo" &&
            problema.mensagem.contains("ECC")) {
          return true;
        }
      }

      return false;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(_titulo()),
      ),
      body: Column(
        children: [

          /// 🔥 BOTÃO MANEJO
          Padding(
            padding: const EdgeInsets.all(12),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.agriculture),
                label: Text(
                  filtrados.isEmpty
                      ? "Nenhum animal disponível"
                      : "Iniciar manejo (${filtrados.length})",
                ),
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.all(16),
                  backgroundColor: filtrados.isEmpty
                      ? Colors.grey
                      : AppColors.primary,
                ),
                onPressed: filtrados.isEmpty
                    ? null
                    : () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => CurralScreen(
                              animaisFiltrados: filtrados,
                            ),
                          ),
                        );
                      },
              ),
            ),
          ),

          /// 📋 LISTA
          Expanded(
            child: filtrados.isEmpty
                ? const Center(
                    child: Text(
                      "Nenhum animal encontrado para esse filtro",
                      style: TextStyle(fontSize: 16),
                    ),
                  )
                : ListView.builder(
                    itemCount: filtrados.length,
                    itemBuilder: (context, index) {
                      final a = filtrados[index];

                      final resultado =
                          AnaliseService.analisarAnimalCompleto(a);

                      return Card(
                        margin: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        child: ListTile(
                          title: Text("Animal ${a.identificacao}"),
                          subtitle: Text(
                            "Peso: ${a.peso.toStringAsFixed(1)} kg\nStatus: ${resultado.status}",
                          ),
                          trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  String _titulo() {
    switch (tipo) {
      case "acao":
        return "Requer ação";
      case "observacao":
        return "Em observação";
      case "verminose_critica":
        return "Alta carga parasitária";
      case "verminose_atencao":
        return "Observação para verminose";
      case "ecc_baixo":
        return "Baixa condição corporal";
      default:
        return "Saudáveis";
    }
  }
}