import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../../models/animal.dart';
import '../../core/services/hive_service.dart';
import '../../core/services/db_service.dart';
import '../../core/theme/app_colors.dart';
import '../../services/dashboard_service.dart';

import '../../utils/fake_data.dart';

import '../../widgets/card_padrao.dart';
import '../../widgets/indicador_card.dart';
import '../../widgets/alerta_item.dart';

import '../rebanho/rebanho_screen.dart';
import '../manejos/manejos_screen.dart';
import '../manejos/curral_screen.dart';
import '../animal/cadastro_animal_screen.dart';
import 'animal_list_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final box = HiveService.animalBox;

    return Scaffold(
      appBar: AppBar(
        title: const Text("OvinoTech"),
        centerTitle: true,
      ),
      backgroundColor: AppColors.fundo,

      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.primary,
        child: const Icon(Icons.add),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => const CadastroAnimalScreen(),
            ),
          );
        },
      ),

      body: ValueListenableBuilder(
        valueListenable: box.listenable(),
        builder: (context, Box<Animal> box, _) {
          final animais = box.values.toList();

          final resumo = DashboardService.gerarResumo(animais);
          final alertas = DashboardService.gerarAlertas(animais);
          final melhores = DashboardService.melhoresAnimais(animais);
          final piores = DashboardService.pioresAnimais(animais);

          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 80),
            children: [

              /// 🔥 BOTÕES DEV (MELHORADOS)
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.auto_fix_high),
                      label: const Text("Gerar dados"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        padding: const EdgeInsets.all(14),
                      ),
                      onPressed: () async {
                        final animais = FakeData.gerarLote(30);

                        for (var a in animais) {
                          await DBService.addAnimal(a);
                        }

                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text("Dados gerados com sucesso"),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.delete),
                      label: const Text("Limpar"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        padding: const EdgeInsets.all(14),
                      ),
                      onPressed: () async {
                        await Hive.box<Animal>('animals').clear();
                        await Hive.box('pesagens').clear();
                        await Hive.box('famacha').clear();
                        await Hive.box('ecc').clear();

                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text("Banco limpo"),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 16),

              /// 🔥 VISÃO DO REBANHO
              const Text(
                "Visão do Rebanho",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
              ),

              const SizedBox(height: 16),

              CardPadrao(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [

                    Text(
                      _mensagemResumo(resumo),
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: resumo.vermelho > 0
                            ? AppColors.vermelho
                            : resumo.amarelo > 0
                                ? AppColors.amarelo
                                : AppColors.verde,
                      ),
                    ),

                    const SizedBox(height: 8),

                    Text("🐑 ${resumo.total} animais"),

                    const SizedBox(height: 16),

                    Row(
                      children: [
                        _statusCard(context, "Saudáveis", resumo.verde, AppColors.verde),
                        _statusCard(context, "Em observação", resumo.amarelo, AppColors.amarelo),
                        _statusCard(context, "Requer ação", resumo.vermelho, AppColors.vermelho),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 16),

              IndicadorCard(
                icon: Icons.monitor_weight,
                valor: "${resumo.pesoMedio.toStringAsFixed(1)} kg",
                titulo: "Peso médio",
              ),

              const SizedBox(height: 28),

              /// ALERTAS
              const Text("Alertas", style: TextStyle(fontSize: 24)),

              ...alertas.map((a) => AlertaItem(texto: a.mensagem)),

              const SizedBox(height: 28),

              /// MELHORES
              const Text("Melhores Animais", style: TextStyle(fontSize: 24)),

              ...melhores.map((a) => ListTile(
                    title: Text("Animal ${a.brinco}"),
                    subtitle: Text("${a.peso?.toStringAsFixed(1)} kg"),
                  )),

              const SizedBox(height: 28),

              /// PIORES
              const Text("Requer ação", style: TextStyle(fontSize: 24)),

              ...piores.map((a) => ListTile(
                    title: Text("Animal ${a.brinco}"),
                    subtitle: Text("${a.peso?.toStringAsFixed(1)} kg"),
                  )),

              const SizedBox(height: 28),

              /// BOTÕES PRINCIPAIS
              CardPadrao(
                child: ListTile(
                  leading: const Icon(Icons.agriculture, color: Colors.green),
                  title: const Text("Modo Curral"),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const CurralScreen(),
                      ),
                    );
                  },
                ),
              ),

              const SizedBox(height: 10),

              ElevatedButton.icon(
                icon: const Icon(Icons.pets),
                label: const Text("Rebanho"),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const RebanhoScreen(),
                    ),
                  );
                },
              ),

              const SizedBox(height: 10),

              ElevatedButton.icon(
                icon: const Icon(Icons.build),
                label: const Text("Manejos"),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const ManejosScreen(),
                    ),
                  );
                },
              ),
            ],
          );
        },
      ),
    );
  }

  String _mensagemResumo(resumo) {
    if (resumo.vermelho > 0) {
      return "⚠️ ${resumo.vermelho} animais requerem ação";
    } else if (resumo.amarelo > 0) {
      return "⚠️ ${resumo.amarelo} em observação";
    } else {
      return "✅ Rebanho saudável";
    }
  }

  Widget _statusCard(BuildContext context, String label, int valor, Color cor) {
    return Expanded(
      child: GestureDetector(
        onTap: () {
          String tipo = label == "Requer ação"
              ? "acao"
              : label == "Em observação"
                  ? "observacao"
                  : "saudavel";

          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => AnimalListScreen(tipo: tipo),
            ),
          );
        },
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 4),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: cor.withOpacity(0.15),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: [
              Icon(Icons.circle, color: cor),
              const SizedBox(height: 6),
              Text("$valor", style: TextStyle(color: cor, fontWeight: FontWeight.bold)),
              Text(label),
            ],
          ),
        ),
      ),
    );
  }
}