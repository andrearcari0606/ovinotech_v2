import 'package:hive_flutter/hive_flutter.dart';
import 'package:firebase_core/firebase_core.dart';

import '../../models/animal.dart';
import '../../models/manejo.dart';
import '../../models/pesagem.dart';
import '../../models/famacha.dart';
import '../../models/ecc.dart';

import 'db_service.dart';

class AppInit {
  static bool _iniciado = false;

  static Future<void> init() async {
    if (_iniciado) return;

    await Firebase.initializeApp();
    await Hive.initFlutter();

    /// ❌ REMOVE ISSO (CAUSAVA O ERRO)
    // await Hive.deleteFromDisk();

    /// 🔥 REGISTRO SEGURO
    if (!Hive.isAdapterRegistered(0)) {
      Hive.registerAdapter(AnimalAdapter());
    }

    if (!Hive.isAdapterRegistered(10)) {
      Hive.registerAdapter(ManejoAdapter());
    }

    if (!Hive.isAdapterRegistered(1)) {
      Hive.registerAdapter(PesagemAdapter());
    }

    if (!Hive.isAdapterRegistered(2)) {
      Hive.registerAdapter(FamachaAdapter());
    }

    if (!Hive.isAdapterRegistered(4)) {
      Hive.registerAdapter(ECCAdapter());
    }

    /// 🔥 BOXES
    await DBService.init();
    await Hive.openBox<Manejo>('manejos');
    await Hive.openBox<Pesagem>('pesagens');
    await Hive.openBox<Famacha>('famacha');
    await Hive.openBox<ECC>('ecc');

    _iniciado = true;
  }
}