import 'package:hive_flutter/hive_flutter.dart';

import '../../models/animal.dart';
import '../../models/pesagem.dart';
import '../../models/reproducao.dart';
import '../../models/famacha.dart';
import '../../models/ecc.dart';
import '../../models/config_manejo.dart';

class HiveService {
  /// 🔥 APENAS GETTERS (SEM INIT, SEM OPEN)

  static Box<Animal> get animalBox => Hive.box<Animal>('animals');

  static Box<Pesagem> get pesagemBox => Hive.box<Pesagem>('pesagens');

  static Box<Reproducao> get reproducaoBox =>
      Hive.box<Reproducao>('reproducao');

  static Box<Famacha> get famachaBox => Hive.box<Famacha>('famacha');

  static Box<ECC> get eccBox => Hive.box<ECC>('ecc');

  static Box<ConfigManejo> get configBox =>
      Hive.box<ConfigManejo>('configBox');
}