import 'package:hive/hive.dart';

class Pesagem {
  String id; // 🔥 AGORA TEM ID (ESSENCIAL)
  String animalId;
  double peso;
  DateTime data;
  String observacao;

  Pesagem({
    required this.id,
    required this.animalId,
    required this.peso,
    required this.data,
    required this.observacao,
  });

  /// 🔥 PARA FIREBASE
  Map<String, dynamic> toMap() {
    return {
      'animalId': animalId,
      'peso': peso,
      'data': data.toIso8601String(),
      'observacao': observacao,
    };
  }

  /// 🔥 LER DO FIREBASE
  factory Pesagem.fromMap(Map<String, dynamic> map, String id) {
    return Pesagem(
      id: id,
      animalId: map['animalId'] ?? "",
      peso: (map['peso'] ?? 0).toDouble(),
      data: DateTime.parse(map['data']),
      observacao: map['observacao'] ?? "",
    );
  }
}

/// 🔥 ADAPTER ATUALIZADO (IMPORTANTE)
class PesagemAdapter extends TypeAdapter<Pesagem> {
  @override
  final typeId = 2;

  @override
  Pesagem read(BinaryReader reader) {
    return Pesagem(
      id: reader.read(),
      animalId: reader.read(),
      peso: reader.read(),
      data: reader.read(),
      observacao: reader.read(),
    );
  }

  @override
  void write(BinaryWriter writer, Pesagem obj) {
    writer.write(obj.id);
    writer.write(obj.animalId);
    writer.write(obj.peso);
    writer.write(obj.data);
    writer.write(obj.observacao);
  }
}