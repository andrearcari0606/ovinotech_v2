import 'package:flutter/material.dart';

import '../../core/services/hive_service.dart';
import '../../models/animal.dart';
import '../../models/ecc.dart';
import '../../models/famacha.dart';
import '../../models/pesagem.dart';
import '../../services/animal_service.dart';
import '../../services/pesagem_service.dart';

class CurralScreen extends StatefulWidget {
  final List<Animal>? animaisFiltrados;

  const CurralScreen({super.key, this.animaisFiltrados});

  @override
  State<CurralScreen> createState() => _CurralScreenState();
}

class ManejoTemp {
  double? peso;
  int? famacha;
  int? ecc;
  String? famachaId;
  String? eccId;
  String? pesagemId;
  bool alterado = false;
}

class _CurralScreenState extends State<CurralScreen> {
  final TextEditingController pesoController = TextEditingController();
  final animalService = AnimalService();

  final Map<String, ManejoTemp> dados = {};

  Animal? animalSelecionado;
  int indexAtual = 0;

  List<Animal> get lista =>
      widget.animaisFiltrados ?? animalService.listar();

  String getId(Animal a) {
    final id =
        a.id ?? a.brinco ?? DateTime.now().millisecondsSinceEpoch.toString();
    a.id = id;
    return id;
  }

  ManejoTemp getAtual(Animal a) {
    final id = getId(a);
    dados.putIfAbsent(id, () => ManejoTemp());
    return dados[id]!;
  }

  /// 🔥 CORRIGIDO: AGORA TRAZ PESO TAMBÉM
  ManejoTemp carregarResumoAnimal(Animal animal) {
    final id = getId(animal);
    final manejo = ManejoTemp();

    final famacha = HiveService.famachaBox.values
        .where((f) => f.animalId == id)
        .toList();

    if (famacha.isNotEmpty) {
      famacha.sort((a, b) => b.data.compareTo(a.data));
      manejo.famacha = famacha.first.nota;
    }

    final ecc = HiveService.eccBox.values
        .where((e) => e.animalId == id)
        .toList();

    if (ecc.isNotEmpty) {
      ecc.sort((a, b) => b.data.compareTo(a.data));
      manejo.ecc = ecc.first.nota;
    }

    /// 🔥 AQUI FOI ADICIONADO (PESO)
    final pesagens = HiveService.pesagemBox.values
        .where((p) => p.animalId == id)
        .toList();

    if (pesagens.isNotEmpty) {
      pesagens.sort((a, b) => b.data.compareTo(a.data));
      manejo.peso = pesagens.first.peso;
    }

    return manejo;
  }

  @override
  void initState() {
    super.initState();
    if (lista.isNotEmpty) {
      animalSelecionado = lista.first;
      pesoController.clear();
    }
  }

  Color corStatus(ManejoTemp m) {
    if (m.famacha == null && m.ecc == null) return Colors.grey;

    if ((m.famacha ?? 0) >= 4 || (m.ecc ?? 5) <= 2) {
      return Colors.red;
    }

    if ((m.famacha ?? 0) == 3) {
      return Colors.orange;
    }

    return Colors.green;
  }

  String dataUltimaPesagem(Animal animal) {
    final pesagens = HiveService.pesagemBox.values
        .where((p) => p.animalId == animal.id)
        .toList();

    if (pesagens.isEmpty) return "Sem pesagem";

    pesagens.sort((a, b) => b.data.compareTo(a.data));
    final d = pesagens.first.data;

    return "${d.day}/${d.month}/${d.year}";
  }

  Future<void> salvarParcial(Animal animal, ManejoTemp manejo) async {
    if (!manejo.alterado) return;

    final animalId = getId(animal);
    final agora = DateTime.now();

    if (manejo.famacha != null) {
      await HiveService.famachaBox.put(
        'famacha_${animalId}_$agora',
        Famacha(
          id: 'famacha_${animalId}_$agora',
          animalId: animalId,
          nota: manejo.famacha!,
          data: agora,
        ),
      );
    }

    if (manejo.ecc != null) {
      await HiveService.eccBox.put(
        'ecc_${animalId}_$agora',
        ECC(
          id: 'ecc_${animalId}_$agora',
          animalId: animalId,
          nota: manejo.ecc!,
          data: agora,
        ),
      );
    }

    if (manejo.peso != null) {
      await PesagemService().salvarPesagem(
        Pesagem(
          id: 'pesagem_${animalId}_$agora',
          animalId: animalId,
          peso: manejo.peso!,
          data: agora,
          observacao: 'Curral',
        ),
      );

      animal.peso = manejo.peso!;
      await HiveService.animalBox.put(animalId, animal);
    }

    manejo.alterado = false;
  }

  void proximoAnimal() async {
    final animal = animalSelecionado;
    if (animal == null) return;

    await salvarParcial(animal, getAtual(animal));

    if (indexAtual < lista.length - 1) {
      setState(() {
        indexAtual++;
        animalSelecionado = lista[indexAtual];
        pesoController.clear();
      });
    } else {
      mostrarResumo();
    }
  }

  void voltarAnimal() {
    if (indexAtual > 0) {
      setState(() {
        indexAtual--;
        animalSelecionado = lista[indexAtual];
        pesoController.clear();
      });
    }
  }

  void pularAnimal() {
    if (indexAtual < lista.length - 1) {
      setState(() {
        indexAtual++;
        animalSelecionado = lista[indexAtual];
        pesoController.clear();
      });
    } else {
      mostrarResumo();
    }
  }

  void mostrarResumo() {
    int saudavel = 0;
    int atencao = 0;
    int critico = 0;

    for (final animal in lista) {
      final m = carregarResumoAnimal(animal);

      if ((m.famacha ?? 0) >= 4 || (m.ecc ?? 5) <= 2) {
        critico++;
      } else if ((m.famacha ?? 0) == 3) {
        atencao++;
      } else if (m.famacha != null || m.ecc != null) {
        saudavel++;
      }
    }

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Resumo do Manejo"),
        content: Text(
          "Saudáveis: $saudavel\n"
          "Atenção: $atencao\n"
          "Críticos: $critico",
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Continuar"),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text("Finalizar"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final animal = animalSelecionado;
    if (animal == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Modo Curral')),
        body: const Center(child: Text('Nenhum animal')),
      );
    }

    final manejo = carregarResumoAnimal(animal);
    final statusCor = corStatus(manejo);
    final avaliado = manejo.famacha != null || manejo.ecc != null;

    final famachaDesc = [
      "Sem anemia",
      "Leve",
      "Atenção",
      "Anemia",
      "Grave"
    ];

    final eccTextos = [
      "Muito magro",
      "Magro",
      "Ideal",
      "Gordo",
      "Muito gordo"
    ];

    final coresFamacha = [
      Color(0xFFB71C1C),
      Color(0xFFD32F2F),
      Color(0xFFF48FB1),
      Color(0xFFFFCDD2),
      Color(0xFFF5F5F5),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Modo Curral')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [

            Text('Animal ${indexAtual + 1} de ${lista.length}'),
            const SizedBox(height: 6),
            LinearProgressIndicator(
              value: (indexAtual + 1) / lista.length,
            ),

            const SizedBox(height: 16),

            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: statusCor.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: statusCor, width: 2),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Brinco ${animal.brinco}',
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  Text('Categoria ${animal.categoria}'),
                  Row(
                    children: [
                      Text(
                        '${(manejo.peso ?? animal.peso).toStringAsFixed(1)} kg',
                      ),
                      const SizedBox(width: 10),
                      Text(dataUltimaPesagem(animal)),
                    ],
                  ),

                  const SizedBox(height: 6),

                  Text(
                    avaliado ? "✔ Já avaliado" : "⚠ Não avaliado",
                    style: TextStyle(
                      color: avaliado ? Colors.green : Colors.orange,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            Row(
              children: List.generate(5, (i) {
                final valor = i + 1;
                final selecionado = getAtual(animal).famacha == valor;

                return Expanded(
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        final m = getAtual(animal);
                        m.famacha = valor;
                        m.alterado = true;
                      });
                    },
                    onLongPress: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(famachaDesc[i])),
                      );
                    },
                    child: Container(
                      height: 55,
                      margin: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: coresFamacha[i],
                        borderRadius: BorderRadius.circular(8),
                        border: selecionado
                            ? Border.all(color: Colors.black, width: 3)
                            : null,
                      ),
                      child: Center(child: Text('$valor')),
                    ),
                  ),
                );
              }),
            ),

            const SizedBox(height: 6),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: const [
                Text('1-2 OK', style: TextStyle(fontSize: 10)),
                Text('3 Atenção', style: TextStyle(fontSize: 10)),
                Text('4-5 Tratar', style: TextStyle(fontSize: 10)),
              ],
            ),

            const SizedBox(height: 16),

            Row(
              children: List.generate(5, (i) {
                final valor = i + 1;
                final selecionado = getAtual(animal).ecc == valor;

                return Expanded(
                  child: GestureDetector(
                    onTap: () {
                      setState(() {
                        final m = getAtual(animal);
                        m.ecc = valor;
                        m.alterado = true;
                      });
                    },
                    child: Container(
                      height: 60,
                      margin: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: selecionado ? Colors.green : Colors.grey.shade200,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text('$valor'),
                          Text(eccTextos[i], style: const TextStyle(fontSize: 10)),
                        ],
                      ),
                    ),
                  ),
                );
              }),
            ),

            const SizedBox(height: 16),

            TextField(
              controller: pesoController,
              decoration: const InputDecoration(labelText: 'Peso'),
              onChanged: (v) {
                final m = getAtual(animal);
                m.peso = double.tryParse(v);
                m.alterado = true;
              },
            ),

            const SizedBox(height: 20),

            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: indexAtual == 0 ? null : voltarAnimal,
                    child: const Text('Voltar'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton(
                    onPressed: pularAnimal,
                    child: const Text('Pular'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton(
                    onPressed: proximoAnimal,
                    child: const Text('Próximo'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}