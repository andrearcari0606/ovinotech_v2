import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:hive/hive.dart';

import '../models/pesagem.dart';

class PesagemService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Box<Pesagem> get box => Hive.box<Pesagem>('pesagens');

  Future<String> _getUserId() async {
    User? user = _auth.currentUser;

    if (user == null) {
      final cred = await _auth.signInAnonymously();
      user = cred.user;
    }

    if (user == null) {
      throw Exception('Falha ao autenticar usuario');
    }

    return user.uid;
  }

  Future<void> salvarPesagem(Pesagem pesagem) async {
    try {
      await box.put(pesagem.id, pesagem);

      try {
        final userId = await _getUserId();

        await _firestore
            .collection('usuarios')
            .doc(userId)
            .collection('pesagens')
            .doc(pesagem.id)
            .set(pesagem.toMap());
      } catch (e) {
        print('Falha ao salvar pesagem no Firebase: $e');
      }
    } catch (e) {
      print('Erro ao salvar pesagem: $e');
      rethrow;
    }
  }

  List<Pesagem> listarPorAnimal(String animalId) {
    return box.values
        .where((p) => p.animalId == animalId)
        .toList()
      ..sort((a, b) => b.data.compareTo(a.data));
  }
}
