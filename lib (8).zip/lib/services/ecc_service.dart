import 'package:hive_flutter/hive_flutter.dart';
import '../models/ecc.dart';

class ECCService {

  /// 🔥 SOMENTE ACESSO
  Box<ECC> get box => Hive.box<ECC>('ecc');

  /// 🔥 SALVAR
  Future<void> salvar(ECC ecc) async {
    await box.put(ecc.id, ecc);
  }

  /// 🔍 LISTAR
  List<ECC> listarPorAnimal(String animalId) {
    return box.values
        .where((e) => e.animalId == animalId)
        .toList()
      ..sort((a, b) => b.data.compareTo(a.data));
  }
}