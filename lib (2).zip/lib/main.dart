import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'screens/dashboard/dashboard_screen.dart';

// MODELS
import 'models/animal.dart';
import 'models/manejo.dart';
import 'models/pesagem.dart';
import 'models/famacha.dart';
import 'models/ecc.dart';
import 'models/reproducao.dart';
import 'models/sanidade.dart';
import 'models/config_manejo.dart';
import 'models/settings.dart';

/// 🔥 DETECTA E LIMPA HIVE CORROMPIDO
Future<void> limparHiveSeCorrompido() async {
  try {
    // tenta abrir uma box crítica
    final box = await Hive.openBox('pesagens');
    await box.close();
  } catch (e) {
    print("🔥 Hive corrompido detectado → limpando tudo");
    await Hive.deleteFromDisk();
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  /// 🔥 FIREBASE
  await Firebase.initializeApp();

  /// 🔥 HIVE INIT
  await Hive.initFlutter();

  /// 🔥 LIMPEZA INTELIGENTE
  await limparHiveSeCorrompido();

  /// 🔥 REGISTRO DE ADAPTERS

  if (!Hive.isAdapterRegistered(3)) {
    Hive.registerAdapter(OrigemAnimalAdapter());
  }

  if (!Hive.isAdapterRegistered(0)) {
    Hive.registerAdapter(AnimalAdapter());
  }

  if (!Hive.isAdapterRegistered(1)) {
    Hive.registerAdapter(PesagemAdapter());
  }

  if (!Hive.isAdapterRegistered(2)) {
    Hive.registerAdapter(FamachaAdapter());
  }

  if (!Hive.isAdapterRegistered(4)) {
    Hive.registerAdapter(ECCAdapter());
  }

  if (!Hive.isAdapterRegistered(5)) {
    Hive.registerAdapter(ReproducaoAdapter());
  }

  if (!Hive.isAdapterRegistered(6)) {
    Hive.registerAdapter(ConfigManejoAdapter());
  }

  if (!Hive.isAdapterRegistered(7)) {
    Hive.registerAdapter(SettingsAdapter());
  }

  if (!Hive.isAdapterRegistered(8)) {
    Hive.registerAdapter(SanidadeAdapter());
  }

  if (!Hive.isAdapterRegistered(10)) {
    Hive.registerAdapter(ManejoAdapter());
  }

  /// 🔥 ABRIR BOXES NORMALMENTE
  await Hive.openBox<Animal>('animals');
  await Hive.openBox<Manejo>('manejos');
  await Hive.openBox<Pesagem>('pesagens');
  await Hive.openBox<Famacha>('famacha');
  await Hive.openBox<ECC>('ecc');
  await Hive.openBox<Reproducao>('reproducao');
  await Hive.openBox<ConfigManejo>('configBox');
  await Hive.openBox<Settings>('settingsBox');
  await Hive.openBox<Sanidade>('sanidade');

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'OvinoTech',
      debugShowCheckedModeBanner: false,
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('pt', 'BR'),
        Locale('en', 'US'),
      ],
      locale: const Locale('pt', 'BR'),
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      home: const DashboardScreen(),
    );
  }
}