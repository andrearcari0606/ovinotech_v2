import 'package:flutter/material.dart';

import '../../models/animal.dart';
import '../../core/services/hive_service.dart';
import '../../services/analise_service.dart';
import '../manejos/curral_screen.dart';

class AnimalDetailScreen extends StatelessWidget {
  final Animal animal;

  const AnimalDetailScreen({
    super.key,
    required this.animal,
  });

  @override
  Widget build(BuildContext context) {
    final resultado =
        AnaliseService.analisarAnimalCompleto(animal);

    final status = resultado.status;

    Color cor;
    String textoStatus;

    if (status == "vermelho") {
      cor = Colors.red;
      textoStatus = "Requer ação";
    } else if (status == "amarelo") {
      cor = Colors.orange;
      textoStatus = "Em observação";
    } else {
      cor = Colors.green;
      textoStatus = "Saudável";
    }

    final pesagens = HiveService.pesagemBox.values
        .where((p) => p.animalId == animal.id)
        .toList();

    pesagens.sort((a, b) => b.data.compareTo(a.data));

    final pesoAtual =
        pesagens.isNotEmpty ? pesagens.first.peso : animal.peso;

    final dataPeso = pesagens.isNotEmpty
        ? pesagens.first.data
        : null;

    final famachas = HiveService.famachaBox.values
        .where((f) => f.animalId == animal.id)
        .toList();

    famachas.sort((a, b) => b.data.compareTo(a.data));

    final eccs = HiveService.eccBox.values
        .where((e) => e.animalId == animal.id)
        .toList();

    eccs.sort((a, b) => b.data.compareTo(a.data));

    String formatarData(DateTime? d) {
      if (d == null) return "-";
      return "${d.day}/${d.month}/${d.year}";
    }

    return Scaffold(
      appBar: AppBar(
        title: Text("Animal ${animal.identificacao}"),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            /// HEADER
            Text(
              "Animal ${animal.identificacao}",
              style: const TextStyle(
                  fontSize: 22, fontWeight: FontWeight.bold),
            ),
            Text("Categoria: ${animal.categoria}"),

            const SizedBox(height: 16),

            /// STATUS
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: cor.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: cor, width: 2),
              ),
              child: Text(
                textoStatus,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: cor,
                ),
              ),
            ),

            const SizedBox(height: 16),

            /// PESO
            Card(
              child: ListTile(
                title: const Text("Peso"),
                subtitle: Text(
                  "${pesoAtual.toStringAsFixed(1)} kg | ${formatarData(dataPeso)}",
                ),
              ),
            ),

            /// SANIDADE
            Card(
              child: ListTile(
                title: const Text("Famacha"),
                subtitle: Text(
                  famachas.isEmpty
                      ? "Não avaliado"
                      : "${famachas.first.nota} | ${formatarData(famachas.first.data)}",
                ),
              ),
            ),

            Card(
              child: ListTile(
                title: const Text("ECC"),
                subtitle: Text(
                  eccs.isEmpty
                      ? "Não avaliado"
                      : "${eccs.first.nota} | ${formatarData(eccs.first.data)}",
                ),
              ),
            ),

            const SizedBox(height: 16),

            /// PROBLEMAS
            if (resultado.problemas.isNotEmpty) ...[
              const Text(
                "⚠ Problemas",
                style: TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 16),
              ),
              const SizedBox(height: 8),
              ...resultado.problemas.map(
                (p) => Text("- ${p.mensagem}"),
              ),
              const SizedBox(height: 16),
            ],

            const SizedBox(height: 20),

            /// AÇÃO
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.agriculture),
                label: const Text("Ir para o curral"),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => CurralScreen(
                        animaisFiltrados: [animal],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}