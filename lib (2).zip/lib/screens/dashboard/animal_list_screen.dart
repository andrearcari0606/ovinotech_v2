import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../../models/animal.dart';
import '../../core/services/hive_service.dart';
import '../../core/theme/app_colors.dart';
import '../../services/analise_service.dart';

import '../manejos/curral_screen.dart';

class AnimalListScreen extends StatelessWidget {
  final String tipo;

  const AnimalListScreen({
    super.key,
    required this.tipo,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_titulo()),
      ),
      body: ValueListenableBuilder<Box<Animal>>(
        valueListenable: HiveService.animalBox.listenable(),
        builder: (context, box, _) {
          final animais = box.values.toList();

          final filtrados = animais.where((a) {
            final resultado =
                AnaliseService.analisarAnimalCompleto(a);

            final status = resultado.status;

            if (tipo == "acao") return status == "vermelho";
            if (tipo == "observacao") return status == "amarelo";
            if (tipo == "saudavel") return status == "verde";

            for (var problema in resultado.problemas) {
              if (tipo == "verminose_critica" &&
                  problema.mensagem.contains("Forte indicativo")) {
                return true;
              }

              if (tipo == "verminose_atencao" &&
                  problema.mensagem.contains("Atenção para verminose")) {
                return true;
              }

              if (tipo == "ecc_baixo" &&
                  problema.mensagem.contains("ECC")) {
                return true;
              }
            }

            return false;
          }).toList();

          return Column(
            children: [

              /// BOTÃO MANEJO (SEM ALTERAR)
              Padding(
                padding: const EdgeInsets.all(12),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.agriculture),
                    label: Text(
                      filtrados.isEmpty
                          ? "Nenhum animal disponível"
                          : "Iniciar manejo (${filtrados.length})",
                    ),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.all(16),
                      backgroundColor: filtrados.isEmpty
                          ? Colors.grey
                          : AppColors.primary,
                    ),
                    onPressed: filtrados.isEmpty
                        ? null
                        : () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => CurralScreen(
                                  animaisFiltrados: filtrados,
                                ),
                              ),
                            );
                          },
                  ),
                ),
              ),

              /// LISTA
              Expanded(
                child: filtrados.isEmpty
                    ? const Center(
                        child: Text(
                          "Nenhum animal encontrado para esse filtro",
                          style: TextStyle(fontSize: 16),
                        ),
                      )
                    : ListView.builder(
                        itemCount: filtrados.length,
                        itemBuilder: (context, index) {
                          final a = filtrados[index];

                          final resultado =
                              AnaliseService.analisarAnimalCompleto(a);

                          Color cor;
                          if (resultado.status == "vermelho") {
                            cor = Colors.red;
                          } else if (resultado.status == "amarelo") {
                            cor = Colors.orange;
                          } else {
                            cor = Colors.green;
                          }

                          return GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) =>
                                      AnimalDetailScreen(animal: a),
                                ),
                              );
                            },
                            child: Container(
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: cor.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: cor, width: 2),
                              ),
                              child: ListTile(
                                title: Text(
                                  "Animal ${a.identificacao}",
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold),
                                ),
                                subtitle: Text(
                                  "Peso: ${a.peso.toStringAsFixed(1)} kg\nStatus: ${resultado.status}",
                                ),
                                trailing: Icon(
                                  Icons.arrow_forward_ios,
                                  size: 16,
                                  color: cor,
                                ),
                              ),
                            ),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }

  String _titulo() {
    switch (tipo) {
      case "acao":
        return "Requer ação";
      case "observacao":
        return "Em observação";
      case "verminose_critica":
        return "Alta carga parasitária";
      case "verminose_atencao":
        return "Observação para verminose";
      case "ecc_baixo":
        return "Baixa condição corporal";
      default:
        return "Saudáveis";
    }
  }
}

class AnimalDetailScreen extends StatelessWidget {
  final Animal animal;

  const AnimalDetailScreen({super.key, required this.animal});

  @override
  Widget build(BuildContext context) {
    final resultado =
        AnaliseService.analisarAnimalCompleto(animal);

    return Scaffold(
      appBar: AppBar(
        title: Text("Animal ${animal.identificacao}"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            Text(
              "Peso: ${animal.peso.toStringAsFixed(1)} kg",
              style: const TextStyle(fontSize: 18),
            ),

            const SizedBox(height: 8),

            Text(
              "Status: ${resultado.status}",
              style: const TextStyle(fontSize: 18),
            ),

            const SizedBox(height: 20),

            const Text(
              "Problemas identificados:",
              style: TextStyle(fontWeight: FontWeight.bold),
            ),

            ...resultado.problemas.map(
              (p) => Text("- ${p.mensagem}"),
            ),

            const Spacer(),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.agriculture),
                label: const Text("Ir para o curral (animal)"),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => CurralScreen(
                        animaisFiltrados: [animal],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}