import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../../models/animal.dart';
import '../../core/services/hive_service.dart';
import '../../services/analise_service.dart';

import 'animal_list_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("OvinoTech"),
            Text(
              "Gestão inteligente do rebanho",
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
        actions: [
          IconButton(icon: const Icon(Icons.add), onPressed: () {}),
          IconButton(icon: const Icon(Icons.settings), onPressed: () {}),
        ],
      ),
      body: ValueListenableBuilder<Box<Animal>>(
        valueListenable: HiveService.animalBox.listenable(),
        builder: (context, box, _) {
          final animais = box.values.toList();

          int saudavel = 0;
          int atencao = 0;
          int critico = 0;

          int verminose = 0;
          int eccBaixo = 0;
          int semAvaliacao = 0;

          double somaPeso = 0;
          int comPeso = 0;

          for (final a in animais) {
            final r = AnaliseService.analisarAnimalCompleto(a);

            if (r.status == "vermelho") {
              critico++;
            } else if (r.status == "amarelo") {
              atencao++;
            } else {
              saudavel++;
            }

            bool temDados = false;

            for (var p in r.problemas) {
              if (p.mensagem.contains("verminose")) verminose++;
              if (p.mensagem.contains("ECC")) eccBaixo++;
            }

            final famacha = HiveService.famachaBox.values
                .where((f) => f.animalId == a.id)
                .toList();

            if (famacha.isNotEmpty) temDados = true;

            if (!temDados) semAvaliacao++;

            final pesagens = HiveService.pesagemBox.values
                .where((p) => p.animalId == a.id)
                .toList();

            if (pesagens.isNotEmpty) {
              pesagens.sort((a, b) => b.data.compareTo(a.data));
              somaPeso += pesagens.first.peso;
              comPeso++;
            }
          }

          final pesoMedio =
              comPeso > 0 ? (somaPeso / comPeso) : 0;

          String statusGeral = "Saudável";
          if (critico > 0) {
            statusGeral = "Requer atenção";
          } else if (atencao > saudavel) {
            statusGeral = "Em observação";
          }

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [

              /// 🔥 CARDS STATUS PREMIUM
              Row(
                children: [
                  Expanded(
                    child: _cardStatus(
                        context, saudavel, "Saudáveis", Colors.green, "saudavel"),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _cardStatus(
                        context, atencao, "Observação", Colors.orange, "observacao"),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _cardStatus(
                        context, critico, "Ação", Colors.red, "acao"),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              /// 🔴 URGÊNCIA
              if (critico > 0)
                _cardInfo(
                  "⚠ $critico animais precisam de ação imediata",
                  Colors.red,
                ),

              /// 🟡 SEM AVALIAÇÃO
              if (semAvaliacao > 0)
                _cardInfo(
                  "⚠ $semAvaliacao animais sem avaliação recente",
                  Colors.orange,
                ),

              const SizedBox(height: 10),

              /// 🧠 DISTRIBUIÇÃO
              if (verminose > 0 || eccBaixo > 0)
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text("Problemas detectados",
                            style: TextStyle(fontWeight: FontWeight.bold)),
                        if (verminose > 0)
                          Text("• $verminose indicativo de verminose"),
                        if (eccBaixo > 0)
                          Text("• $eccBaixo ECC baixo"),
                      ],
                    ),
                  ),
                ),

              const SizedBox(height: 10),

              /// ⚖️ PESO
              if (comPeso > 0)
                Text(
                  "Peso médio: ${pesoMedio.toStringAsFixed(1)} kg",
                  style: const TextStyle(fontSize: 16),
                ),

              const SizedBox(height: 10),

              /// 📊 STATUS GERAL
              Text(
                "Situação do rebanho: $statusGeral",
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _cardStatus(BuildContext context, int valor, String titulo,
      Color cor, String tipo) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => AnimalListScreen(tipo: tipo),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: cor.withOpacity(0.12),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: cor, width: 1.5),
        ),
        child: Column(
          children: [
            Text(
              valor.toString(),
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: cor,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              titulo,
              style: const TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  Widget _cardInfo(String texto, Color cor) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: cor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: cor),
      ),
      child: Text(texto),
    );
  }
}