import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

import '../models/animal.dart';
import '../models/pesagem.dart';
import '../core/services/hive_service.dart';
import '../services/pesagem_service.dart';

class PesoChart extends StatelessWidget {
  final Animal animal;

  const PesoChart({super.key, required this.animal});

  @override
  Widget build(BuildContext context) {
    final lista = PesagemService().listarPorAnimal(animal.id!);

    if (lista.length < 2) {
      return const Text("Sem dados para gráfico");
    }

    lista.sort((a, b) => a.data.compareTo(b.data));

    final spotsAnimal = <FlSpot>[];

    for (int i = 0; i < lista.length; i++) {
      spotsAnimal.add(FlSpot(i.toDouble(), lista[i].peso));
    }

    final todosAnimais = HiveService.getAnimaisAtivos();

    final spotsMedia = <FlSpot>[];

    for (int i = 0; i < lista.length; i++) {
      final dataRef = lista[i].data;

      List<double> pesosMesmoDia = [];

      for (var a in todosAnimais) {
        final pesagens = PesagemService().listarPorAnimal(a.id!);

        Pesagem? maisProxima;
        int? menorDiferenca;

        for (var p in pesagens) {
          final diff =
              (p.data.difference(dataRef).inDays).abs();

          if (diff <= 7) {
            if (menorDiferenca == null ||
                diff < menorDiferenca) {
              menorDiferenca = diff;
              maisProxima = p;
            }
          }
        }

        if (maisProxima != null) {
          pesosMesmoDia.add(maisProxima.peso);
        }
      }

      if (pesosMesmoDia.isNotEmpty) {
        final media =
            pesosMesmoDia.reduce((a, b) => a + b) /
                pesosMesmoDia.length;

        spotsMedia.add(FlSpot(i.toDouble(), media));
      }
    }

    final corLinha =
        lista.last.peso >= lista.first.peso
            ? Colors.green
            : Colors.red;

    return SizedBox(
      height: 250,
      child: LineChart(
        LineChartData(
          lineBarsData: [
            LineChartBarData(
              spots: spotsMedia,
              isCurved: true,
              color: Colors.blue,
              barWidth: 3,
              dotData: FlDotData(show: false),
            ),
            LineChartBarData(
              spots: spotsAnimal,
              isCurved: true,
              color: corLinha,
              barWidth: 4,
              dotData: FlDotData(show: true),
            ),
          ],
        ),
      ),
    );
  }
}